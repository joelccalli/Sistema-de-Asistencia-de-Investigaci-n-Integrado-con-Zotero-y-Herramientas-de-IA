## About Tag

You can long click on the tag below to see its internal pseudo-code.
You can type #xxx and enter to create a tag and save it with Ctrl + S, during which you can execute it with Ctrl + R.
You can right-click and long-click a tag to delete it.

## About Output Text
You can double click on this text to copy GPT's answer.
You can long press me without releasing, then move me to a suitable position before releasing.

## About Input Text
You can type the question in my header, enter and ask me a question.
You can exit me by pressing Esc above my head and wake me up by pressing Shift + / in the Zotero window.